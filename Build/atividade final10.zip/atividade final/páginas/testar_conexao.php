<?php
$hostname = "localhost";  // Endereço do servidor MySQL
$bancodedados = "contato_portfolio";  // Nome do banco de dados
$usuario = "root";  // Nome do usuário MySQL
$senha = "77128667Pg";  // Senha fornecida para o usuário root

// Conexão com o banco de dados
$mysqli = new mysqli($hostname, $usuario, $senha, $bancodedados);

// Verificar a conexão
if ($mysqli->connect_errno) {
    echo "Falha ao conectar: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
} else {
    echo "Conexão bem-sucedida com o banco de dados!";
}
?>
