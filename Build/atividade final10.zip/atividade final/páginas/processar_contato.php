<?php
// processar_contato.php - COM SUA SENHA
$servidor = "127.0.0.1";  // Workbench
$usuario = "root";
$senha = "77128667Pg";    // SUA SENHA AQUI!
$banco = "contato_portfolio";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Conectar ao Workbench COM SENHA
        $conexao = new mysqli($servidor, $usuario, $senha, $banco);
        
        if ($conexao->connect_error) {
            throw new Exception("❌ Erro conexão: " . $conexao->connect_error);
        }
        
        // Pegar dados do formulário
        $nome = $conexao->real_escape_string($_POST['nome']);
        $telefone = $conexao->real_escape_string($_POST['telefone']);
        $email = $conexao->real_escape_string($_POST['email']);
        $empresa = $conexao->real_escape_string($_POST['empresa']);
        $assunto = $conexao->real_escape_string($_POST['assunto']);
        $mensagem = $conexao->real_escape_string($_POST['mensagem']);
        
        // Inserir no banco
        $sql = "INSERT INTO mensagens (nome, telefone, email, empresa, assunto, mensagem) 
                VALUES ('$nome', '$telefone', '$email', '$empresa', '$assunto', '$mensagem')";
        
        if ($conexao->query($sql)) {
            echo "<script>
                alert('✅ Mensagem salva no MySQL Workbench!');
                window.location.href = 'formulario.html';
            </script>";
        } else {
            throw new Exception("Erro ao salvar: " . $conexao->error);
        }
        
        $conexao->close();
        
    } catch (Exception $e) {
        echo "<script>
            alert('" . $e->getMessage() . "');
            window.location.href = 'formulario.html';
        </script>";
    }
    exit();
} else {
    echo "<script>window.location.href = 'formulario.html';</script>";
    exit();
}
?>