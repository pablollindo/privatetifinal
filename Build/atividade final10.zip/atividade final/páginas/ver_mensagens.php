<?php
// ver_mensagens.php - COM SUA SENHA
$servidor = "127.0.0.1";
$usuario = "root";
$senha = "77128667Pg";    // SUA SENHA AQUI!
$banco = "contato_portfolio";

$conexao = new mysqli($servidor, $usuario, $senha, $banco);

if ($conexao->connect_error) {
    die("❌ Erro conexão: " . $conexao->connect_error);
}

$sql = "SELECT * FROM mensagens ORDER BY data_envio DESC";
$resultado = $conexao->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Mensagens Recebidas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h1>📨 Mensagens no Workbench: <?php echo $resultado->num_rows; ?></h1>
    
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Telefone</th>
                    <th>Assunto</th>
                    <th>Data</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $resultado->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo htmlspecialchars($row['nome']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['telefone']); ?></td>
                    <td><?php echo htmlspecialchars($row['assunto']); ?></td>
                    <td><?php echo date('d/m/Y H:i', strtotime($row['data_envio'])); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    
    <a href="formulario.html" class="btn btn-primary">← Voltar ao Formulário</a>
</body>
</html>