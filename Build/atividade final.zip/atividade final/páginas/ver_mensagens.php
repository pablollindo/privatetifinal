<?php
// Dados de conexão
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "contato_portfolio";
$porta = 3309;

// Conectar ao banco
try {
    $conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);
    
    if ($conexao->connect_error) {
        throw new Exception("Erro de conexão: " . $conexao->connect_error);
    }
} catch (Exception $e) {
    die("<h1>❌ ERRO: " . $e->getMessage() . "</h1>");
}

// Buscar mensagem para editar
$id = $_GET['id'] ?? 0;
$mensagem_data = null;

if ($id) {
    $sql = "SELECT * FROM mensagens WHERE id = $id";
    $resultado = $conexao->query($sql);
    if ($resultado->num_rows > 0) {
        $mensagem_data = $resultado->fetch_assoc();
    }
}

// Processar atualização
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $conexao->real_escape_string($_POST['nome']);
    $telefone = $conexao->real_escape_string($_POST['telefone']);
    $email = $conexao->real_escape_string($_POST['email']);
    $empresa = $conexao->real_escape_string($_POST['empresa']);
    $assunto = $conexao->real_escape_string($_POST['assunto']);
    $mensagem_texto = $conexao->real_escape_string($_POST['mensagem']);
    
    $sql = "UPDATE mensagens SET 
            nome = '$nome',
            telefone = '$telefone', 
            email = '$email',
            empresa = '$empresa',
            assunto = '$assunto',
            mensagem = '$mensagem_texto'
            WHERE id = $id";
    
    if ($conexao->query($sql)) {
        header("Location: ver_mensagens.php");
        exit;
    } else {
        $erro = "❌ ERRO AO ATUALIZAR: " . $conexao->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Mensagem</title>
</head>
<body>
    <h1>✏️ EDITAR MENSAGEM #<?php echo $id; ?></h1>
    <hr>

    <?php if (isset($erro)): ?>
        <p style="color: red;"><strong><?php echo $erro; ?></strong></p>
    <?php endif; ?>
    
    <?php if ($mensagem_data): ?>
    <form method="POST">
        <p><strong>Nome:</strong><br>
        <input type="text" name="nome" value="<?php echo $mensagem_data['nome']; ?>" style="width: 300px; padding: 5px;" required></p>
        
        <p><strong>Email:</strong><br>
        <input type="email" name="email" value="<?php echo $mensagem_data['email']; ?>" style="width: 300px; padding: 5px;" required></p>
        
        <p><strong>Telefone:</strong><br>
        <input type="text" name="telefone" value="<?php echo $mensagem_data['telefone']; ?>" style="width: 300px; padding: 5px;"></p>
        
        <p><strong>Empresa:</strong><br>
        <input type="text" name="empresa" value="<?php echo $mensagem_data['empresa']; ?>" style="width: 300px; padding: 5px;"></p>
        
        <p><strong>Assunto:</strong><br>
        <input type="text" name="assunto" value="<?php echo $mensagem_data['assunto']; ?>" style="width: 300px; padding: 5px;" required></p>
        
        <p><strong>Mensagem:</strong><br>
        <textarea name="mensagem" style="width: 500px; height: 150px; padding: 5px;" required><?php echo $mensagem_data['mensagem']; ?></textarea></p>
        
        <button type="submit" style="background: #28a745; color: white; padding: 10px 20px; border: none; border-radius: 5px;">💾 SALVAR ALTERAÇÕES</button>
        <a href="ver_mensagens.php" style="background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-left: 10px;">↩️ CANCELAR</a>
    </form>
    <?php else: ?>
        <p style="color: red;">Mensagem não encontrada.</p>
    <?php endif; ?>
</body>
</html>