<?php
// Dados de conexão
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "contato_portfolio";
$porta = 3309;

// Verificar se é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    echo "<h1>✅ MENSAGEM RECEBIDA COM SUCESSO!</h1>";
    echo "<hr>";
    
    echo "<h2>📋 DADOS RECEBIDOS:</h2>";
    echo "<p><strong>Nome:</strong> " . ($_POST['nome'] ?? 'Não informado') . "</p>";
    echo "<p><strong>Email:</strong> " . ($_POST['email'] ?? 'Não informado') . "</p>";
    echo "<p><strong>Telefone:</strong> " . ($_POST['telefone'] ?? 'Não informado') . "</p>";
    echo "<p><strong>Empresa:</strong> " . ($_POST['empresa'] ?? 'Não informada') . "</p>";
    echo "<p><strong>Assunto:</strong> " . ($_POST['assunto'] ?? 'Não informado') . "</p>";
    echo "<p><strong>Mensagem:</strong><br>" . ($_POST['mensagem'] ?? 'Não informada') . "</p>";
    
    echo "<hr>";
    echo "<h2>🗄️ STATUS DO BANCO DE DADOS:</h2>";
    
    try {
        $conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);
        
        if ($conexao->connect_error) {
            echo "<p style='color: red'><strong>❌ ERRO DE CONEXÃO:</strong> " . $conexao->connect_error . "</p>";
        } else {
            echo "<p style='color: green'><strong>✅ CONEXÃO:</strong> Conectado ao MySQL com sucesso!</p>";
            
            // Inserir dados
            $nome = $conexao->real_escape_string($_POST['nome']);
            $telefone = $conexao->real_escape_string($_POST['telefone']);
            $email = $conexao->real_escape_string($_POST['email']);
            $empresa = $conexao->real_escape_string($_POST['empresa'] ?? '');
            $assunto = $conexao->real_escape_string($_POST['assunto']);
            $mensagem = $conexao->real_escape_string($_POST['mensagem']);
            
            $sql = "INSERT INTO mensagens (nome, telefone, email, empresa, assunto, mensagem) 
                    VALUES ('$nome', '$telefone', '$email', '$empresa', '$assunto', '$mensagem')";
            
            if ($conexao->query($sql)) {
                echo "<p style='color: green'><strong>✅ SALVO NO BANCO:</strong> Dados armazenados com sucesso!</p>";
                echo "<p><strong>ID do Registro:</strong> " . $conexao->insert_id . "</p>";
                echo "<p><strong>Data/Hora:</strong> " . date('d/m/Y H:i:s') . "</p>";
            } else {
                echo "<p style='color: red'><strong>❌ ERRO AO SALVAR:</strong> " . $conexao->error . "</p>";
            }
            
            $conexao->close();
        }
    } catch (Exception $e) {
        echo "<p style='color: red'><strong>❌ EXCEÇÃO:</strong> " . $e->getMessage() . "</p>";
    }
    
    echo "<hr>";
    echo '<br><a href="formulario.html" style="background: #2563eb; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;">← Voltar ao Formulário</a>';
    echo '<a href="painel_mensagens.php" style="background: #17a2b8; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">📊 Ir para Painel</a>';
    
} else {
    echo "<h1>⚠️ ACESSO NEGADO</h1>";
    echo "<p>Esta página só pode ser acessada através do formulário.</p>";
    echo '<a href="formulario.html">Ir para o formulário</a>';
}
?>