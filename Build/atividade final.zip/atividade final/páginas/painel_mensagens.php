<?php
// Dados de conexão
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "contato_portfolio";
$porta = 3309;

// Conectar ao banco
try {
    $conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);
    
    if ($conexao->connect_error) {
        throw new Exception("Erro de conexão: " . $conexao->connect_error);
    }
} catch (Exception $e) {
    die("<h1>❌ ERRO: " . $e->getMessage() . "</h1>");
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Mensagens</title>
</head>
<body>
    <h1>📊 PAINEL DE MENSAGENS</h1>
    <hr>

    <?php
    // Estatísticas
    $sql_count = "SELECT COUNT(*) as total FROM mensagens";
    $result_count = $conexao->query($sql_count);
    $total_mensagens = $result_count->fetch_assoc()['total'];
    
    echo "<h2>📈 ESTATÍSTICAS</h2>";
    echo "<p><strong>Total de Mensagens:</strong> " . $total_mensagens . "</p>";
    echo "<hr>";
    ?>

    <h2>📋 TODAS AS MENSAGENS</h2>
    
    <?php
    // Buscar todas mensagens
    $sql = "SELECT * FROM mensagens ORDER BY data_envio DESC";
    $resultado = $conexao->query($sql);
    
    if ($resultado->num_rows > 0) {
        while($mensagem = $resultado->fetch_assoc()) {
            echo "<h3>📄 MENSAGEM #" . $mensagem['id'] . "</h3>";
            echo "<p><strong>Nome:</strong> " . $mensagem['nome'] . "</p>";
            echo "<p><strong>Email:</strong> " . $mensagem['email'] . "</p>";
            echo "<p><strong>Telefone:</strong> " . ($mensagem['telefone'] ?: 'Não informado') . "</p>";
            echo "<p><strong>Empresa:</strong> " . ($mensagem['empresa'] ?: 'Não informada') . "</p>";
            echo "<p><strong>Assunto:</strong> " . $mensagem['assunto'] . "</p>";
            echo "<p><strong>Mensagem:</strong><br>" . nl2br($mensagem['mensagem']) . "</p>";
            echo "<p><strong>Data/Hora:</strong> " . $mensagem['data_envio'] . "</p>";
            
            // BOTÕES DE AÇÃO
            echo "<p>";
            echo "<a href='editar_mensagem.php?id=" . $mensagem['id'] . "' style='background: #ffc107; color: black; padding: 8px 15px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>✏️ EDITAR</a>";
            echo "<a href='excluir_mensagem.php?id=" . $mensagem['id'] . "' style='background: #dc3545; color: white; padding: 8px 15px; text-decoration: none; border-radius: 4px;' onclick='return confirm(\"Tem certeza que deseja excluir esta mensagem?\")'>🗑️ EXCLUIR</a>";
            echo "</p>";
            echo "<hr>";
        }
    } else {
        echo "<p>Nenhuma mensagem encontrada no banco de dados.</p>";
    }
    
    $conexao->close();
    ?>
    
    <br>
    <div>
        <a href="formulario.html" style="background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;">📝 NOVA MENSAGEM</a>
        <a href="index.html" style="background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">🏠 VOLTAR AO PORTFÓLIO</a>
    </div>
</body>
</html>