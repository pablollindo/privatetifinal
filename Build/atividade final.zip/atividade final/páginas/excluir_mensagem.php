<?php
// Dados de conexão
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "contato_portfolio";
$porta = 3309;

// Conectar ao banco
try {
    $conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);
    
    if ($conexao->connect_error) {
        throw new Exception("Erro de conexão: " . $conexao->connect_error);
    }
} catch (Exception $e) {
    die("<h1>❌ ERRO: " . $e->getMessage() . "</h1>");
}

// Excluir mensagem
$id = $_GET['id'] ?? 0;

if ($id) {
    $sql = "DELETE FROM mensagens WHERE id = $id";
    if ($conexao->query($sql)) {
        header("Location: painel_mensagens.php");
        exit;
    } else {
        echo "<h1>❌ ERRO AO EXCLUIR</h1>";
        echo "<p>" . $conexao->error . "</p>";
    }
} else {
    echo "<h1>❌ ID NÃO ESPECIFICADO</h1>";
}

$conexao->close();

echo "<br>";
echo "<a href='painel_mensagens.php' style='background: #2563eb; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>📋 VOLTAR AO PAINEL</a>";